import React, { useState, useRef } from "react";
import { PageContainer, DogList, DogItem, DogForm, Buttons, TabButton, KillTheDog } from "./homeStyles";
import { dogs } from "./dogsData";

export default function Home() {
	const dogsCount = useRef(dogs.length);
	const [listOfDogs, setListOfDogs] = useState(dogs);
	const [activeTab, setActiveTab] = useState('list-of-dogs');
	const [shelterStorage, setShelterStorage] = useState({
		food: 27,
		vaccine: 6,
		pills: 12
	});
	const [tempShelterStorage, setTempShelterStorage] = useState({
		food: "",
		vaccine: "",
		pills: ""
	});
	const dogsRequirements = {
		food: 5,
		vaccine: 1,
		pills: 2
	};
	const [addDog, setAddDog] = useState({
		id: (dogsCount.current + 1),
		name: "",
		race: "",
		age: 0
	});
	const handleChange = (e) => {
		setAddDog({...addDog, [e.target.name]: e.target.value});
	};
	const handleAdd = async (e) => {
		e.preventDefault();
		let pushDog = false;
		let totalRequirements = {
			food: (dogsRequirements.food * (listOfDogs.length + 1)),
			vaccine: (dogsRequirements.vaccine * (listOfDogs.length + 1)),
			pills: (dogsRequirements.pills * (listOfDogs.length + 1)),
		};
		if (
			totalRequirements.food <= shelterStorage.food &&
			totalRequirements.vaccine <= shelterStorage.vaccine &&
			totalRequirements.pills <= shelterStorage.pills
		) {
			pushDog = true;
		}
		console.log(`pushDog ${pushDog}`);
		if (pushDog) {
			await setListOfDogs((listOfDogs) => {
				return [...listOfDogs, addDog];
			});
			dogsCount.current++;
			await setAddDog({
				id: (dogsCount.current + 1),
				name: "",
				race: "",
				age: 0
			});
		} else {
			console.warn('Malo zásob pro tolik psů.');
		}
		pushDog = false;
	};
	const handleDelete = (id) => {
		setListOfDogs(listOfDogs.filter( dog => dog.id != id));
	};
	const handleStorage = (e) => {
		setTempShelterStorage({ ...tempShelterStorage, [e.target.name]: e.target.value});
	};
	const updateStorage = async () => {
		const storageValue = tempShelterStorage;
		let newStorageValue = {};
		// storageValue = {food: "", vaccine: "", pills: ""}
		const keys = Object.keys(storageValue);
		// keys = ['food', 'vaccine', 'pills']
		// key = keys[1]
		keys.map((key) => {
			// storageValue.vaccine
			if (parseInt(storageValue[key])) {
				newStorageValue[key] = parseInt(shelterStorage[key]) + parseInt(storageValue[key]);
			} else {
				newStorageValue[key] = parseInt(shelterStorage[key]);
			}
		})
		await setShelterStorage(newStorageValue);
		await setTempShelterStorage({ food: "", vaccine: "", pills: ""});
	};
	const switchTab = (e, newValue) => {
		e.preventDefault();
		const newActiveTab = newValue;
		setActiveTab(newActiveTab);
	};
	// useEffect(() => {
	// 	setPushDog(false);
	// }, [listOfDogs])

	return (
		<PageContainer>
			<Buttons>
				<TabButton name="list-of-dogs" activeTab={activeTab} onClick={(event) => { switchTab(event, 'list-of-dogs') }}>
					Seznam Psů
				</TabButton>
				<TabButton name="shelter-storage" activeTab={activeTab} onClick={(event) => { switchTab(event, 'shelter-storage') }}>
					Sklad útulku
				</TabButton>
			</Buttons>
			{ (activeTab === 'list-of-dogs') && 
				<>
					<DogList name="dogList">
						{
								listOfDogs.map((dog) => (
									<DogItem key={dog.id} name={dog.name}>
										{dog.name} / {dog.race} / {dog.age}
										<KillTheDog
											onClick={() => {handleDelete(dog.id)}}
										>
											x
										</KillTheDog>
									</DogItem>
								))
						}
					</DogList>
					<DogForm name="dogForm">
						<input
							type="text"
							placeholder="jméno psa"
							className="inputClass"
							name="name"
							value={addDog.name}
							onChange={handleChange}
						/>
						<input
							type="text"
							placeholder="rasa psa"
							className="inputClass"
							name="race"
							value={addDog.race}
							onChange={handleChange}
						/>
						<input
							type="number"
							min="0"
							max="25"
							placeholder="věk psa"
							className="inputClass"
							name="age"
							value={addDog.age}
							onChange={handleChange}
						/>
						<button
							className="inputClass"
							onClick={handleAdd}
						>
							Přidat
						</button>
					</DogForm>
				</>
			}
			{ (activeTab === 'shelter-storage') &&
				<>
					<DogForm style={{ flexDirection: 'column '}}>
						<div
							className="inputClass"
							style={{color: 'white', height: 'auto'}}
						>
							<b>Aktuální zásoby</b>
							<p>
								krmivo: {shelterStorage.food},
								vakcíny: {shelterStorage.vaccine},
								tabletky: {shelterStorage.pills}
							</p>
						</div>
						<input
							type="number"
							placeholder="krmivo (kg)"
							className="inputClass"
							name="food"
							value={tempShelterStorage.food}
							onChange={handleStorage}
						/>
						<input
							type="number"
							placeholder="vakcíny (ks)"
							className="inputClass"
							name="vaccine"
							value={tempShelterStorage.vaccine}
							onChange={handleStorage}
						/>
						<input
							type="number"
							placeholder="tabletky (ks)"
							className="inputClass"
							name="pills"
							value={tempShelterStorage.pills}
							onChange={handleStorage}
						/>
						<button
							className="inputClass"
							onClick={updateStorage}
						>
							Doplnit zásoby
						</button>
					</DogForm>
				</>
			}
		</PageContainer>
	);
}
