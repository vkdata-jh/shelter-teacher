/* eslint-disable */
export const dogs = [
  {
    id: 1,
    name: "Rex",
    race: "Smeták",
    age: 7,
  },
  {
    id: 2,
    name: "Joy",
    race: "Jezevčík",
    age: 5,
  },
  {
    id: 3,
    name: "Hvězdička",
    race: "Vořech",
    age: 11,
  },
  {
    id: 4,
    name: "Bibi",
    race: "Kokršpaněl",
    age: 2,
  },
  {
    id: 5,
    name: "Jinx",
    race: "bullteriér",
    age: 3,
  },
];
